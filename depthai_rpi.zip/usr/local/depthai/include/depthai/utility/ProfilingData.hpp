#pragma once

namespace dai {

struct ProfilingData {
    long long numBytesWritten;
    long long numBytesRead;
};

}  // namespace dai
