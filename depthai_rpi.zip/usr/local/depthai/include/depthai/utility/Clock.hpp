#pragma once

#include <chrono>

namespace dai {

using Clock = std::chrono::steady_clock;

}  // namespace dai
